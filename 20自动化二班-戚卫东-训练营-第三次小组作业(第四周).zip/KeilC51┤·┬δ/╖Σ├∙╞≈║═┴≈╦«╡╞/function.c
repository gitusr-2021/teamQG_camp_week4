/***************************************************************************************
 *	FileName					:function.c
 *	CopyRight					:
 *	ModuleName					:
 *
 *	CPU							:
 *	RTOS						:
 *
 *	Create Date					:2021.4.21
 *	Author/Corportation			:������
 *
 *	Abstract Description		:QG�ڶ���С��������
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Date			Revised By			Item			Description
 * 	
 *
 ***************************************************************************************/
/**************************************************************
*	Include File Section
**************************************************************/
#include <reg51.h>

/**************************************************************
*	Function Define Section
**************************************************************/

/**
 *  @name:delay
 *	@description:��ʱ����
 *	@param��none
 *	@return��none
 *  @notice��none
 */
void delay(void)
{
	int i,j;

	for(i = 200; i > 0; i--)
	{
		for(j = 500; j > 0; j--)
		{
		}
	}
}

